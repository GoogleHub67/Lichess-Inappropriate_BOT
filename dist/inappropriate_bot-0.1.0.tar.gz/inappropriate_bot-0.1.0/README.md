# Inappropriate_BOT - Adaptive Chess Partner

A Lichess bot that dynamically adapts its playing strength to match 
your live skill level using centipawn loss analysis. The harder you 
play, the harder it plays back.

Built by Aarav Patel.

---

## How it works

Game starts
    |
    v
Bot plays at default ELO (1200)
    |
    v
Tracks your centipawn loss per move
    |   -> rolling average CPL
    |
    v
Maps avg CPL -> Stockfish ELO
    |   CPL <= 15  -> ELO 2200 (master)
    |   CPL <= 25  -> ELO 2000 (expert)
    |   CPL <= 40  -> ELO 1800 (strong club)
    |   CPL <= 60  -> ELO 1600 (intermediate)
    |   CPL <= 90  -> ELO 1400 (casual)
    |   CPL <= 130 -> ELO 1200 (beginner)
    |   CPL > 130  -> ELO 1000 (newcomer)
    v
Plays at that ELO for the rest of the game

---

## Features
- Fully adaptive strength based on live CPL
- Supports all Lichess variants
- Smart draw handling (accepts when losing, declines when winning)
- Auto-resigns when mated in 3 or less
- Takeback support
- Multiple concurrent games
- Automatic stream reconnection
- Works with bullet, blitz, rapid, classical, correspondence

---

## Setup

### 1. Install dependencies
pip install -r requirements.txt

### 2. Install Stockfish
- Windows: https://stockfishchess.org/download/
- Linux: sudo apt install stockfish
- Mac: brew install stockfish

### 3. Create a Lichess BOT account
- Make a NEW Lichess account (never played any games)
- Go to https://lichess.org/account/oauth/token/create
- Tick only bot:play scope
- Copy the token

### 4. Configure
Create a .env file:
```
LICHESS_TOKEN=lip_yourtoken
```

Update STOCKFISH_PATH in config.py to your Stockfish location.

### 5. Run
python bot.py

---

## File structure
- bot.py             - Main entry point, event stream, challenge handler
- game_handler.py    - Per-game loop and move logic
- skill_estimator.py - CPL tracker and ELO mapper
- config.py          - All settings
- requirements.txt   - Python dependencies

---

## Contributing
Pull requests are welcome! Please credit the original author (Aarav Patel) in any forks.

## Known Limitations
- Requires Stockfish installed locally
- Needs at least 3 opponent moves before CPL kicks in

## Credits
- [Stockfish](https://stockfishchess.org/) - Chess engine
- [python-chess](https://python-chess.readthedocs.io/) - Chess library

## License
MIT License - Copyright (c) 2026 Aarav Patel